<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TdSet extends Model
{
    use HasFactory;

    public const STATUS_DRAFT = 'draft';
    public const STATUS_SUBMITTED = 'submitted';
    public const STATUS_PUBLISHED = 'published';
    public const STATUS_ARCHIVED = 'archived';

    public const ACCESS_FREE = 'free';
    public const ACCESS_PREMIUM = 'premium';

    public const CORRECTION_IMMEDIATE = 'immediate';
    public const CORRECTION_AFTER_SUBMIT = 'after_submit';
    public const CORRECTION_SCHEDULED = 'scheduled';
    public const CORRECTION_PREMIUM_ONLY = 'premium_only';

    protected $fillable = [
        'school_class_id',
        'subject_id',
        'teacher_assignment_id',
        'author_user_id',
        'title',
        'slug',
        'chapter_label',
        'summary',
        'instructions_html',
        'correction_html',
        'difficulty',
        'estimated_minutes',
        'access_level',
        'td_type',
        'status',
        'document_path',
        'document_name',
        'document_mime',
        'document_size',
        'correction_document_path',
        'correction_document_name',
        'correction_document_mime',
        'correction_document_size',
        'correction_mode',
        'correction_release_at',
        'source_type',
        'source_label',
        'license_type',
        'rights_confirmed',
        'published_at',
    ];

    protected $casts = [
        'rights_confirmed' => 'boolean',
        'published_at' => 'datetime',
        'correction_release_at' => 'datetime',
        'estimated_minutes' => 'integer',
        'document_size' => 'integer',
        'correction_document_size' => 'integer',
    ];

    public function schoolClass()
    {
        return $this->belongsTo(SchoolClass::class, 'school_class_id');
    }

    public function subject()
    {
        return $this->belongsTo(Subject::class);
    }

    public function author()
    {
        return $this->belongsTo(User::class, 'author_user_id');
    }

    public function teacherAssignment()
    {
        return $this->belongsTo(TeacherAssignment::class, 'teacher_assignment_id');
    }

    public function attempts()
    {
        return $this->hasMany(TdAttempt::class);
    }

    public function questionThreads()
    {
        return $this->hasMany(TdQuestionThread::class);
    }

    public function scopePublished($query)
    {
        return $query->where('status', self::STATUS_PUBLISHED);
    }

    public function isPublished(): bool
    {
        return $this->status === self::STATUS_PUBLISHED;
    }

    public function isPremium(): bool
    {
        return $this->access_level === self::ACCESS_PREMIUM;
    }
}
