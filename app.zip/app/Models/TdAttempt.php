<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TdAttempt extends Model
{
    use HasFactory;

    public const STATUS_STARTED = 'started';
    public const STATUS_SUBMITTED = 'submitted';

    protected $fillable = [
        'td_set_id',
        'student_id',
        'status',
        'submitted_at',
        'correction_unlocked_at',
    ];

    protected $casts = [
        'submitted_at' => 'datetime',
        'correction_unlocked_at' => 'datetime',
    ];

    public function tdSet()
    {
        return $this->belongsTo(TdSet::class);
    }

    public function student()
    {
        return $this->belongsTo(User::class, 'student_id');
    }
}
