<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\TdQuestionThread;
use App\Models\TdSet;
use App\Models\TeacherAssignment;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;

class DashboardController extends Controller
{
    public function index()
    {
        $teacher = auth()->user();
        $assignments = $this->assignments($teacher->id);
        $tdQuery = TdSet::query()->with(['subject', 'schoolClass']);
        $this->applyAssignments($tdQuery, $assignments);
        $tdQuery->where('author_user_id', $teacher->id);

        $threadQuery = Schema::hasTable('td_question_threads')
            ? TdQuestionThread::query()->where('teacher_id', $teacher->id)->with(['student', 'tdSet', 'subject', 'schoolClass'])
            : null;

        return view('teacher.dashboard', [
            'teacher' => $teacher,
            'assignments' => $assignments,
            'stats' => [
                'classes' => $assignments->pluck('school_class_id')->unique()->count(),
                'subjects' => $assignments->pluck('subject_id')->unique()->count(),
                'td_total' => (clone $tdQuery)->count(),
                'td_draft' => (clone $tdQuery)->where('status', TdSet::STATUS_DRAFT)->count(),
                'td_submitted' => (clone $tdQuery)->where('status', TdSet::STATUS_SUBMITTED)->count(),
                'td_published' => (clone $tdQuery)->where('status', TdSet::STATUS_PUBLISHED)->count(),
                'td_questions' => $threadQuery ? (clone $threadQuery)->count() : 0,
                'td_questions_open' => $threadQuery ? (clone $threadQuery)->where('status', TdQuestionThread::STATUS_OPEN)->count() : 0,
            ],
            'recentTdSets' => (clone $tdQuery)->latest()->take(6)->get(),
            'recentTdThreads' => $threadQuery ? (clone $threadQuery)->latest('last_message_at')->take(6)->get() : collect(),
        ]);
    }

    protected function assignments(int $teacherId): Collection
    {
        if (!Schema::hasTable('teacher_assignments')) {
            return collect();
        }

        return TeacherAssignment::query()
            ->with(['schoolClass', 'subject'])
            ->where('teacher_id', $teacherId)
            ->where('is_active', true)
            ->get();
    }

    protected function applyAssignments($query, Collection $assignments): void
    {
        if ($assignments->isEmpty()) {
            $query->whereRaw('1 = 0');
            return;
        }

        $query->where(function ($builder) use ($assignments) {
            foreach ($assignments as $assignment) {
                $builder->orWhere(function ($inner) use ($assignment) {
                    $inner->where('school_class_id', $assignment->school_class_id)
                        ->where('subject_id', $assignment->subject_id);
                });
            }
        });
    }
}
