<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\TdQuestionMessage;
use App\Models\TdQuestionThread;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class TdQuestionController extends Controller
{
    public function index(Request $request)
    {
        $query = TdQuestionThread::query()->with(['tdSet', 'student', 'subject', 'schoolClass'])
            ->where('teacher_id', auth()->id());

        if ($request->filled('status')) {
            $query->where('status', (string) $request->string('status'));
        }

        $threads = $query->latest('last_message_at')->paginate(16)->withQueryString();

        return view('teacher.td.questions.index', [
            'threads' => $threads,
            'filters' => $request->only('status'),
        ]);
    }

    public function show(TdQuestionThread $thread)
    {
        $this->authorizeThread($thread);
        $thread->load(['tdSet', 'student', 'subject', 'schoolClass', 'messages.sender']);

        TdQuestionMessage::query()
            ->where('thread_id', $thread->id)
            ->where('sender_role', 'student')
            ->where('is_read', false)
            ->update(['is_read' => true]);

        return view('teacher.td.questions.show', compact('thread'));
    }

    public function reply(Request $request, TdQuestionThread $thread)
    {
        $this->authorizeThread($thread);

        $data = $request->validate([
            'message_html' => ['required_without:attachment', 'nullable', 'string'],
            'attachment' => ['nullable', 'file', 'max:20480', 'mimes:pdf,doc,docx,png,jpg,jpeg,txt'],
            'status' => ['nullable', 'in:open,answered,closed'],
        ]);

        [$path, $name, $mime] = $this->storeAttachment($request);

        TdQuestionMessage::query()->create([
            'thread_id' => $thread->id,
            'sender_id' => auth()->id(),
            'sender_role' => 'teacher',
            'message_html' => $data['message_html'] ?? null,
            'attachment_path' => $path,
            'attachment_name' => $name,
            'attachment_mime' => $mime,
            'is_read' => false,
        ]);

        $thread->update([
            'status' => $data['status'] ?? TdQuestionThread::STATUS_ANSWERED,
            'last_message_at' => now(),
        ]);

        return redirect()->route('teacher.td.questions.show', $thread)->with('success', 'Réponse envoyée avec succès.');
    }

    public function attachment(TdQuestionMessage $message)
    {
        $this->authorizeThread($message->thread);
        abort_unless($message->attachment_path, 404);
        $path = storage_path('app/' . $message->attachment_path);
        abort_unless(file_exists($path), 404);

        if (str_starts_with((string) $message->attachment_mime, 'image/') || $message->attachment_mime === 'application/pdf') {
            return response()->file($path, ['Content-Type' => $message->attachment_mime]);
        }

        return response()->download($path, $message->attachment_name ?: basename($path));
    }

    protected function authorizeThread(TdQuestionThread $thread): void
    {
        abort_unless((int) $thread->teacher_id === (int) auth()->id(), 403);
    }

    protected function storeAttachment(Request $request): array
    {
        if (!$request->hasFile('attachment')) {
            return [null, null, null];
        }

        $file = $request->file('attachment');
        $original = $file->getClientOriginalName();
        $storedName = now()->format('YmdHis') . '_' . Str::slug(pathinfo($original, PATHINFO_FILENAME)) . '.' . $file->getClientOriginalExtension();
        $path = $file->storeAs('td-questions/attachments', $storedName);

        return [$path, $original, $file->getMimeType()];
    }
}
