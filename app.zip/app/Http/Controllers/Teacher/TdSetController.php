<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\TdSet;
use App\Models\TeacherAssignment;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class TdSetController extends Controller
{
    public function index(Request $request)
    {
        $assignments = $this->assignments()->keyBy('id');
        $query = TdSet::query()->with(['schoolClass', 'subject', 'teacherAssignment']);
        $this->applyAssignments($query, $assignments->values());
        $query->where('author_user_id', auth()->id());

        if ($request->filled('status')) {
            $query->where('status', (string) $request->string('status'));
        }

        if ($request->filled('subject_id')) {
            $query->where('subject_id', (int) $request->integer('subject_id'));
        }

        if ($request->filled('q')) {
            $term = trim((string) $request->string('q'));
            $query->where(function ($builder) use ($term) {
                $builder->where('title', 'like', "%{$term}%")
                    ->orWhere('summary', 'like', "%{$term}%")
                    ->orWhere('chapter_label', 'like', "%{$term}%");
            });
        }

        $tdSets = $query->latest()->paginate(12)->withQueryString();

        return view('teacher.td.sets.index', [
            'tdSets' => $tdSets,
            'assignments' => $assignments,
            'filters' => $request->only('status', 'subject_id', 'q'),
        ]);
    }

    public function create()
    {
        return view('teacher.td.sets.create', [
            'assignments' => $this->assignments(),
            'tdSet' => new TdSet([
                'difficulty' => 'medium',
                'access_level' => TdSet::ACCESS_FREE,
                'td_type' => 'training',
                'status' => TdSet::STATUS_DRAFT,
                'correction_mode' => TdSet::CORRECTION_AFTER_SUBMIT,
            ]),
        ]);
    }

    public function store(Request $request)
    {
        $assignment = $this->resolveAssignment($request->integer('teacher_assignment_id'));
        $data = $this->validated($request);
        [$documentPath, $documentName, $documentMime, $documentSize] = $this->storeFile($request, 'document', 'td-sets/documents');
        [$correctionPath, $correctionName, $correctionMime, $correctionSize] = $this->storeFile($request, 'correction_document', 'td-sets/corrections');

        TdSet::query()->create([
            'school_class_id' => $assignment->school_class_id,
            'subject_id' => $assignment->subject_id,
            'teacher_assignment_id' => $assignment->id,
            'author_user_id' => auth()->id(),
            'title' => $data['title'],
            'slug' => Str::slug($data['title']) . '-' . now()->timestamp,
            'chapter_label' => $data['chapter_label'] ?? null,
            'summary' => $data['summary'] ?? null,
            'instructions_html' => $data['instructions_html'] ?? '',
            'correction_html' => $data['correction_html'] ?? null,
            'difficulty' => $data['difficulty'],
            'estimated_minutes' => $data['estimated_minutes'] ?? null,
            'access_level' => $data['access_level'],
            'td_type' => $data['td_type'],
            'status' => $data['status'],
            'document_path' => $documentPath,
            'document_name' => $documentName,
            'document_mime' => $documentMime,
            'document_size' => $documentSize,
            'correction_document_path' => $correctionPath,
            'correction_document_name' => $correctionName,
            'correction_document_mime' => $correctionMime,
            'correction_document_size' => $correctionSize,
            'correction_mode' => $data['correction_mode'],
            'correction_release_at' => $data['correction_release_at'] ?? null,
            'source_type' => $data['source_type'] ?? 'original',
            'source_label' => $data['source_label'] ?? null,
            'license_type' => $data['license_type'] ?? null,
            'rights_confirmed' => (bool) ($data['rights_confirmed'] ?? false),
            'published_at' => $data['status'] === TdSet::STATUS_PUBLISHED ? now() : null,
        ]);

        return redirect()->route('teacher.td.sets.index')->with('success', 'TD enregistré avec succès.');
    }

    public function edit(TdSet $tdSet)
    {
        $this->authorizeTdSet($tdSet);

        return view('teacher.td.sets.edit', [
            'tdSet' => $tdSet,
            'assignments' => $this->assignments(),
        ]);
    }

    public function update(Request $request, TdSet $tdSet)
    {
        $this->authorizeTdSet($tdSet);
        $assignment = $this->resolveAssignment($request->integer('teacher_assignment_id'));
        $data = $this->validated($request, true);

        $updates = [
            'school_class_id' => $assignment->school_class_id,
            'subject_id' => $assignment->subject_id,
            'teacher_assignment_id' => $assignment->id,
            'title' => $data['title'],
            'chapter_label' => $data['chapter_label'] ?? null,
            'summary' => $data['summary'] ?? null,
            'instructions_html' => $data['instructions_html'] ?? '',
            'correction_html' => $data['correction_html'] ?? null,
            'difficulty' => $data['difficulty'],
            'estimated_minutes' => $data['estimated_minutes'] ?? null,
            'access_level' => $data['access_level'],
            'td_type' => $data['td_type'],
            'status' => $data['status'],
            'correction_mode' => $data['correction_mode'],
            'correction_release_at' => $data['correction_release_at'] ?? null,
            'source_type' => $data['source_type'] ?? 'original',
            'source_label' => $data['source_label'] ?? null,
            'license_type' => $data['license_type'] ?? null,
            'rights_confirmed' => (bool) ($data['rights_confirmed'] ?? false),
            'published_at' => $data['status'] === TdSet::STATUS_PUBLISHED ? ($tdSet->published_at ?? now()) : null,
        ];

        if ($request->boolean('remove_document') && $tdSet->document_path) {
            $this->deleteFile($tdSet->document_path);
            $updates['document_path'] = null;
            $updates['document_name'] = null;
            $updates['document_mime'] = null;
            $updates['document_size'] = null;
        }

        if ($request->boolean('remove_correction_document') && $tdSet->correction_document_path) {
            $this->deleteFile($tdSet->correction_document_path);
            $updates['correction_document_path'] = null;
            $updates['correction_document_name'] = null;
            $updates['correction_document_mime'] = null;
            $updates['correction_document_size'] = null;
        }

        if ($request->hasFile('document')) {
            if ($tdSet->document_path) {
                $this->deleteFile($tdSet->document_path);
            }
            [$path, $name, $mime, $size] = $this->storeFile($request, 'document', 'td-sets/documents');
            $updates['document_path'] = $path;
            $updates['document_name'] = $name;
            $updates['document_mime'] = $mime;
            $updates['document_size'] = $size;
        }

        if ($request->hasFile('correction_document')) {
            if ($tdSet->correction_document_path) {
                $this->deleteFile($tdSet->correction_document_path);
            }
            [$path, $name, $mime, $size] = $this->storeFile($request, 'correction_document', 'td-sets/corrections');
            $updates['correction_document_path'] = $path;
            $updates['correction_document_name'] = $name;
            $updates['correction_document_mime'] = $mime;
            $updates['correction_document_size'] = $size;
        }

        $tdSet->update($updates);

        return redirect()->route('teacher.td.sets.index')->with('success', 'TD mis à jour avec succès.');
    }

    public function destroy(TdSet $tdSet)
    {
        $this->authorizeTdSet($tdSet);

        if ($tdSet->document_path) {
            $this->deleteFile($tdSet->document_path);
        }
        if ($tdSet->correction_document_path) {
            $this->deleteFile($tdSet->correction_document_path);
        }

        $tdSet->delete();

        return redirect()->route('teacher.td.sets.index')->with('success', 'TD supprimé.');
    }

    public function document(TdSet $tdSet)
    {
        $this->authorizeTdSet($tdSet);
        abort_unless($tdSet->document_path, 404);
        $path = storage_path('app/' . $tdSet->document_path);
        abort_unless(file_exists($path), 404);

        return response()->file($path, ['Content-Type' => $tdSet->document_mime ?: 'application/octet-stream']);
    }

    public function correctionDocument(TdSet $tdSet)
    {
        $this->authorizeTdSet($tdSet);
        abort_unless($tdSet->correction_document_path, 404);
        $path = storage_path('app/' . $tdSet->correction_document_path);
        abort_unless(file_exists($path), 404);

        return response()->file($path, ['Content-Type' => $tdSet->correction_document_mime ?: 'application/octet-stream']);
    }

    protected function validated(Request $request, bool $update = false): array
    {
        return $request->validate([
            'teacher_assignment_id' => ['required', 'integer'],
            'title' => ['required', 'string', 'max:255'],
            'chapter_label' => ['nullable', 'string', 'max:255'],
            'summary' => ['nullable', 'string', 'max:2000'],
            'instructions_html' => ['nullable', 'string'],
            'correction_html' => ['nullable', 'string'],
            'difficulty' => ['required', 'in:easy,medium,exam'],
            'estimated_minutes' => ['nullable', 'integer', 'min:5', 'max:360'],
            'access_level' => ['required', 'in:free,premium'],
            'td_type' => ['required', 'in:training,past_exam,simulation,remedial'],
            'status' => ['required', 'in:draft,submitted,published,archived'],
            'correction_mode' => ['required', 'in:immediate,after_submit,scheduled,premium_only'],
            'correction_release_at' => ['nullable', 'date'],
            'source_type' => ['nullable', 'in:original,curated,past_paper,imported'],
            'source_label' => ['nullable', 'string', 'max:255'],
            'license_type' => ['nullable', 'string', 'max:255'],
            'rights_confirmed' => ['nullable', 'accepted'],
            'document' => ['nullable', 'file', 'max:20480', 'mimes:pdf,doc,docx,ppt,pptx,txt,rtf,odt,jpg,jpeg,png'],
            'correction_document' => ['nullable', 'file', 'max:20480', 'mimes:pdf,doc,docx,ppt,pptx,txt,rtf,odt,jpg,jpeg,png'],
            'remove_document' => ['nullable', 'boolean'],
            'remove_correction_document' => ['nullable', 'boolean'],
        ], [
            'rights_confirmed.accepted' => 'Vous devez confirmer que vous avez le droit de publier ce contenu.',
            'document.mimes' => 'Formats autorisés : PDF, DOC, DOCX, PPT, PPTX, TXT, RTF, ODT, JPG, PNG.',
            'correction_document.mimes' => 'Formats autorisés : PDF, DOC, DOCX, PPT, PPTX, TXT, RTF, ODT, JPG, PNG.',
        ]);
    }

    protected function assignments(): Collection
    {
        if (!Schema::hasTable('teacher_assignments')) {
            return collect();
        }

        return TeacherAssignment::query()
            ->with(['schoolClass', 'subject'])
            ->where('teacher_id', auth()->id())
            ->where('is_active', true)
            ->orderByDesc('id')
            ->get();
    }

    protected function resolveAssignment(?int $assignmentId): TeacherAssignment
    {
        $assignment = $this->assignments()->firstWhere('id', $assignmentId);
        abort_unless($assignment, 403);

        return $assignment;
    }

    protected function authorizeTdSet(TdSet $tdSet): void
    {
        $assignmentIds = $this->assignments()->pluck('id')->map(fn ($value) => (int) $value)->all();

        abort_unless(
            (int) $tdSet->author_user_id === (int) auth()->id()
            || in_array((int) $tdSet->teacher_assignment_id, $assignmentIds, true),
            403
        );
    }

    protected function applyAssignments($query, Collection $assignments): void
    {
        if ($assignments->isEmpty()) {
            $query->whereRaw('1 = 0');
            return;
        }

        $query->where(function ($builder) use ($assignments) {
            foreach ($assignments as $assignment) {
                $builder->orWhere(function ($inner) use ($assignment) {
                    $inner->where('school_class_id', $assignment->school_class_id)
                        ->where('subject_id', $assignment->subject_id);
                });
            }
        });
    }

    protected function storeFile(Request $request, string $field, string $dir): array
    {
        if (!$request->hasFile($field)) {
            return [null, null, null, null];
        }

        $file = $request->file($field);
        $original = $file->getClientOriginalName();
        $storedName = now()->format('YmdHis') . '_' . Str::slug(pathinfo($original, PATHINFO_FILENAME)) . '.' . $file->getClientOriginalExtension();
        $path = $file->storeAs($dir, $storedName);

        return [$path, $original, $file->getMimeType(), $file->getSize()];
    }

    protected function deleteFile(?string $path): void
    {
        if ($path && Storage::exists($path)) {
            Storage::delete($path);
        }
    }
}
