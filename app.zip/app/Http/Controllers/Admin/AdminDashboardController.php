<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\SchoolClass;
use App\Models\Subscription;
use App\Models\TdQuestionThread;
use App\Models\TdSet;
use App\Models\TeacherAssignment;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'users' => class_exists(User::class) ? User::query()->count() : 0,
            'students' => class_exists(User::class) ? User::query()->get()->filter(fn ($user) => method_exists($user, 'isStudent') && $user->isStudent())->count() : 0,
            'teachers' => class_exists(User::class) ? User::query()->get()->filter(fn ($user) => method_exists($user, 'isTeacher') && $user->isTeacher())->count() : 0,
            'classes' => class_exists(SchoolClass::class) ? SchoolClass::query()->count() : 0,
            'assignments' => class_exists(TeacherAssignment::class) && Schema::hasTable('teacher_assignments')
                ? TeacherAssignment::query()->where('is_active', true)->count()
                : 0,
            'active_subscriptions' => class_exists(Subscription::class)
                ? Subscription::query()->where('status', Subscription::STATUS_ACTIVE)->count()
                : 0,
            'payments' => class_exists(Payment::class) ? Payment::query()->count() : 0,
            'pending_payments' => class_exists(Payment::class)
                ? Payment::query()->where('status', 'pending')->count()
                : 0,
            'completed_payments' => class_exists(Payment::class)
                ? Payment::query()->whereIn('status', ['completed', 'paid', 'success'])->count()
                : 0,
            'td_total' => Schema::hasTable('td_sets') ? TdSet::query()->count() : 0,
            'td_published' => Schema::hasTable('td_sets') ? TdSet::query()->where('status', TdSet::STATUS_PUBLISHED)->count() : 0,
            'td_submitted' => Schema::hasTable('td_sets') ? TdSet::query()->where('status', TdSet::STATUS_SUBMITTED)->count() : 0,
            'td_free' => Schema::hasTable('td_sets') ? TdSet::query()->where('access_level', TdSet::ACCESS_FREE)->count() : 0,
            'td_premium' => Schema::hasTable('td_sets') ? TdSet::query()->where('access_level', TdSet::ACCESS_PREMIUM)->count() : 0,
            'td_questions_open' => Schema::hasTable('td_question_threads') ? TdQuestionThread::query()->where('status', TdQuestionThread::STATUS_OPEN)->count() : 0,
        ];

        $recentTds = Schema::hasTable('td_sets')
            ? TdSet::query()->with(['subject', 'schoolClass', 'author'])->latest()->take(6)->get()
            : new Collection();

        $openThreads = Schema::hasTable('td_question_threads')
            ? TdQuestionThread::query()->with(['tdSet', 'student', 'teacher', 'subject', 'schoolClass'])->latest('last_message_at')->take(6)->get()
            : new Collection();

        return view('admin.dashboard', compact('stats', 'recentTds', 'openThreads'));
    }
}
