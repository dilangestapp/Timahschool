<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SchoolClass;
use App\Models\Subject;
use App\Models\TdQuestionMessage;
use App\Models\TdQuestionThread;
use App\Models\TdSet;
use Illuminate\Http\Request;

class AdminTdController extends Controller
{
    public function dashboard()
    {
        return redirect()->route('admin.td.sets.index');
    }

    public function index(Request $request)
    {
        $query = TdSet::query()->with(['schoolClass', 'subject', 'author', 'teacherAssignment.teacher']);

        if ($request->filled('status')) {
            $query->where('status', (string) $request->string('status'));
        }

        if ($request->filled('access_level')) {
            $query->where('access_level', (string) $request->string('access_level'));
        }

        if ($request->filled('school_class_id')) {
            $query->where('school_class_id', (int) $request->integer('school_class_id'));
        }

        if ($request->filled('subject_id')) {
            $query->where('subject_id', (int) $request->integer('subject_id'));
        }

        if ($request->filled('q')) {
            $term = trim((string) $request->string('q'));
            $query->where(function ($builder) use ($term) {
                $builder->where('title', 'like', "%{$term}%")
                    ->orWhere('summary', 'like', "%{$term}%")
                    ->orWhere('chapter_label', 'like', "%{$term}%");
            });
        }

        $tdSets = $query->latest()->paginate(16)->withQueryString();

        return view('admin.td.index', [
            'tdSets' => $tdSets,
            'classes' => SchoolClass::query()->orderBy('name')->get(),
            'subjects' => Subject::query()->orderBy('name')->get(),
            'filters' => $request->only('status', 'access_level', 'school_class_id', 'subject_id', 'q'),
        ]);
    }

    public function show(TdSet $tdSet)
    {
        $tdSet->load(['schoolClass', 'subject', 'author', 'teacherAssignment.teacher']);

        return view('admin.td.show', compact('tdSet'));
    }

    public function publish(TdSet $tdSet)
    {
        $tdSet->update([
            'status' => TdSet::STATUS_PUBLISHED,
            'published_at' => $tdSet->published_at ?? now(),
        ]);

        return back()->with('success', 'TD publié avec succès.');
    }

    public function submitBackToDraft(TdSet $tdSet)
    {
        $tdSet->update([
            'status' => TdSet::STATUS_DRAFT,
            'published_at' => null,
        ]);

        return back()->with('success', 'TD remis en brouillon.');
    }

    public function archive(TdSet $tdSet)
    {
        $tdSet->update(['status' => TdSet::STATUS_ARCHIVED]);

        return back()->with('success', 'TD archivé.');
    }

    public function questions(Request $request)
    {
        $query = TdQuestionThread::query()->with(['tdSet', 'student', 'teacher', 'subject', 'schoolClass']);

        if ($request->filled('status')) {
            $query->where('status', (string) $request->string('status'));
        }

        if ($request->filled('subject_id')) {
            $query->where('subject_id', (int) $request->integer('subject_id'));
        }

        $threads = $query->latest('last_message_at')->paginate(16)->withQueryString();

        return view('admin.td.questions', [
            'threads' => $threads,
            'subjects' => Subject::query()->orderBy('name')->get(),
            'filters' => $request->only('status', 'subject_id'),
        ]);
    }

    public function showQuestion(TdQuestionThread $thread)
    {
        $thread->load(['tdSet', 'student', 'teacher', 'subject', 'schoolClass', 'messages.sender']);

        TdQuestionMessage::query()
            ->where('thread_id', $thread->id)
            ->where('sender_role', '!=', 'admin')
            ->where('is_read', false)
            ->update(['is_read' => true]);

        return view('admin.td.question_show', compact('thread'));
    }

    public function attachment(TdQuestionMessage $message)
    {
        abort_unless($message->attachment_path, 404);
        $path = storage_path('app/' . $message->attachment_path);
        abort_unless(file_exists($path), 404);

        if (str_starts_with((string) $message->attachment_mime, 'image/') || $message->attachment_mime === 'application/pdf') {
            return response()->file($path, ['Content-Type' => $message->attachment_mime]);
        }

        return response()->download($path, $message->attachment_name ?: basename($path));
    }
}
