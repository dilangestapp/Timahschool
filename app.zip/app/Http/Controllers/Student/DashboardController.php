<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Course;
use Illuminate\Support\Facades\Schema;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $studentProfile = $user->studentProfile;

        $recentCourses = collect();
        if ($studentProfile && $studentProfile->school_class_id) {
            $recentCourses = Course::query()
                ->where('school_class_id', $studentProfile->school_class_id)
                ->where('status', Course::STATUS_PUBLISHED)
                ->with('subject')
                ->latest('published_at')
                ->latest('id')
                ->take(6)
                ->get();
        }

        $pendingQuizzes = collect();
        if (
            class_exists('App\\Models\\Quiz')
            && Schema::hasTable('quizzes')
            && Schema::hasTable('quiz_attempts')
            && $studentProfile
            && $studentProfile->school_class_id
        ) {
            $quizModel = app('App\\Models\\Quiz');

            $pendingQuizzes = $quizModel::query()
                ->whereHas('subject.classSubject', function ($q) use ($studentProfile) {
                    $q->where('school_class_id', $studentProfile->school_class_id);
                })
                ->where('status', 'published')
                ->whereDoesntHave('attempts', function ($q) use ($user) {
                    $q->where('user_id', $user->id);
                })
                ->take(3)
                ->get();
        }

        return view('student.dashboard', [
            'user' => $user,
            'studentProfile' => $studentProfile,
            'subscription' => $user->activeSubscription,
            'recentCourses' => $recentCourses,
            'pendingQuizzes' => $pendingQuizzes,
        ]);
    }
}
