<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\TdAttempt;
use App\Models\TdQuestionMessage;
use App\Models\TdQuestionThread;
use App\Models\TdSet;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class TdController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $studentProfile = $user->studentProfile;
        abort_unless($studentProfile && $studentProfile->school_class_id, 403, 'Aucune classe élève n’est rattachée à ce compte.');

        $query = TdSet::query()
            ->with(['subject', 'schoolClass', 'author'])
            ->where('school_class_id', $studentProfile->school_class_id)
            ->where('status', TdSet::STATUS_PUBLISHED);

        if ($request->filled('subject_id')) {
            $query->where('subject_id', (int) $request->integer('subject_id'));
        }

        if ($request->filled('difficulty')) {
            $query->where('difficulty', (string) $request->string('difficulty'));
        }

        if ($request->filled('access_level')) {
            $query->where('access_level', (string) $request->string('access_level'));
        }

        if ($request->filled('q')) {
            $term = trim((string) $request->string('q'));
            $query->where(function ($builder) use ($term) {
                $builder->where('title', 'like', "%{$term}%")
                    ->orWhere('summary', 'like', "%{$term}%")
                    ->orWhere('chapter_label', 'like', "%{$term}%");
            });
        }

        $tdSets = $query->latest()->paginate(12)->withQueryString();
        $subscriptionActive = $user->hasActiveSubscription();

        return view('student.td.index', [
            'tdSets' => $tdSets,
            'studentProfile' => $studentProfile,
            'subscriptionActive' => $subscriptionActive,
            'filters' => $request->only('subject_id', 'difficulty', 'access_level', 'q'),
        ]);
    }

    public function show(TdSet $tdSet)
    {
        $user = auth()->user();
        $studentProfile = $user->studentProfile;
        $this->authorizeStudentTd($tdSet, $studentProfile?->school_class_id);

        $hasPremium = $user->hasActiveSubscription();
        abort_unless($this->canAccessTd($tdSet, $hasPremium), 403, 'Ce TD est réservé à l’offre premium.');

        $attempt = TdAttempt::query()->firstOrCreate(
            ['td_set_id' => $tdSet->id, 'student_id' => $user->id],
            ['status' => TdAttempt::STATUS_STARTED]
        );

        $thread = TdQuestionThread::query()
            ->where('td_set_id', $tdSet->id)
            ->where('student_id', $user->id)
            ->with(['messages.sender'])
            ->first();

        $canViewCorrection = $this->canViewCorrection($tdSet, $attempt, $hasPremium);

        return view('student.td.show', [
            'tdSet' => $tdSet->load(['subject', 'schoolClass', 'author']),
            'attempt' => $attempt,
            'thread' => $thread,
            'subscriptionActive' => $hasPremium,
            'canViewCorrection' => $canViewCorrection,
        ]);
    }

    public function submit(Request $request, TdSet $tdSet)
    {
        $user = auth()->user();
        $studentProfile = $user->studentProfile;
        $this->authorizeStudentTd($tdSet, $studentProfile?->school_class_id);
        abort_unless($this->canAccessTd($tdSet, $user->hasActiveSubscription()), 403);

        $attempt = TdAttempt::query()->firstOrCreate(
            ['td_set_id' => $tdSet->id, 'student_id' => $user->id],
            ['status' => TdAttempt::STATUS_STARTED]
        );

        $attempt->update([
            'status' => TdAttempt::STATUS_SUBMITTED,
            'submitted_at' => now(),
            'correction_unlocked_at' => $tdSet->correction_mode === TdSet::CORRECTION_AFTER_SUBMIT ? now() : $attempt->correction_unlocked_at,
        ]);

        return redirect()->route('student.td.show', $tdSet)->with('success', 'Votre TD est marqué comme terminé.');
    }

    public function ask(Request $request, TdSet $tdSet)
    {
        $user = auth()->user();
        $studentProfile = $user->studentProfile;
        $this->authorizeStudentTd($tdSet, $studentProfile?->school_class_id);
        abort_unless($this->canAccessTd($tdSet, $user->hasActiveSubscription()), 403);

        $data = $request->validate([
            'message_html' => ['required_without:attachment', 'nullable', 'string'],
            'attachment' => ['nullable', 'file', 'max:20480', 'mimes:pdf,doc,docx,png,jpg,jpeg,txt'],
        ]);

        $teacherId = $tdSet->teacherAssignment?->teacher_id ?: $tdSet->author_user_id;
        $thread = TdQuestionThread::query()->firstOrCreate(
            [
                'td_set_id' => $tdSet->id,
                'student_id' => $user->id,
            ],
            [
                'school_class_id' => $tdSet->school_class_id,
                'subject_id' => $tdSet->subject_id,
                'teacher_id' => $teacherId,
                'status' => TdQuestionThread::STATUS_OPEN,
                'last_message_at' => now(),
            ]
        );

        [$path, $name, $mime] = $this->storeAttachment($request);

        TdQuestionMessage::query()->create([
            'thread_id' => $thread->id,
            'sender_id' => $user->id,
            'sender_role' => 'student',
            'message_html' => $data['message_html'] ?? null,
            'attachment_path' => $path,
            'attachment_name' => $name,
            'attachment_mime' => $mime,
            'is_read' => false,
        ]);

        $thread->update([
            'teacher_id' => $teacherId,
            'status' => TdQuestionThread::STATUS_OPEN,
            'last_message_at' => now(),
        ]);

        return redirect()->route('student.td.show', $tdSet)->with('success', 'Votre question a été envoyée à l’enseignant concerné.');
    }

    public function document(TdSet $tdSet)
    {
        $user = auth()->user();
        $this->authorizeStudentTd($tdSet, $user->studentProfile?->school_class_id);
        abort_unless($this->canAccessTd($tdSet, $user->hasActiveSubscription()), 403);
        abort_unless($tdSet->document_path, 404);
        $path = storage_path('app/' . $tdSet->document_path);
        abort_unless(file_exists($path), 404);

        if ($tdSet->document_mime === 'application/pdf' || str_starts_with((string) $tdSet->document_mime, 'image/')) {
            return response()->file($path, ['Content-Type' => $tdSet->document_mime]);
        }

        return response()->download($path, $tdSet->document_name ?: basename($path));
    }

    public function correctionDocument(TdSet $tdSet)
    {
        $user = auth()->user();
        $attempt = TdAttempt::query()->where('td_set_id', $tdSet->id)->where('student_id', $user->id)->first();
        $this->authorizeStudentTd($tdSet, $user->studentProfile?->school_class_id);
        abort_unless($this->canViewCorrection($tdSet, $attempt, $user->hasActiveSubscription()), 403);
        abort_unless($tdSet->correction_document_path, 404);
        $path = storage_path('app/' . $tdSet->correction_document_path);
        abort_unless(file_exists($path), 404);

        if ($tdSet->correction_document_mime === 'application/pdf' || str_starts_with((string) $tdSet->correction_document_mime, 'image/')) {
            return response()->file($path, ['Content-Type' => $tdSet->correction_document_mime]);
        }

        return response()->download($path, $tdSet->correction_document_name ?: basename($path));
    }

    public function attachment(TdQuestionMessage $message)
    {
        $thread = $message->thread()->with('tdSet')->firstOrFail();
        $this->authorizeStudentTd($thread->tdSet, auth()->user()->studentProfile?->school_class_id);
        abort_unless((int) $thread->student_id === (int) auth()->id(), 403);
        abort_unless($message->attachment_path, 404);
        $path = storage_path('app/' . $message->attachment_path);
        abort_unless(file_exists($path), 404);

        if (str_starts_with((string) $message->attachment_mime, 'image/') || $message->attachment_mime === 'application/pdf') {
            return response()->file($path, ['Content-Type' => $message->attachment_mime]);
        }

        return response()->download($path, $message->attachment_name ?: basename($path));
    }

    protected function authorizeStudentTd(TdSet $tdSet, ?int $schoolClassId): void
    {
        abort_unless($schoolClassId && (int) $tdSet->school_class_id === (int) $schoolClassId && $tdSet->status === TdSet::STATUS_PUBLISHED, 403);
    }

    protected function canAccessTd(TdSet $tdSet, bool $hasPremium): bool
    {
        return !$tdSet->isPremium() || $hasPremium;
    }

    protected function canViewCorrection(TdSet $tdSet, ?TdAttempt $attempt, bool $hasPremium): bool
    {
        return match ($tdSet->correction_mode) {
            TdSet::CORRECTION_IMMEDIATE => true,
            TdSet::CORRECTION_AFTER_SUBMIT => (bool) $attempt?->correction_unlocked_at,
            TdSet::CORRECTION_SCHEDULED => $tdSet->correction_release_at && $tdSet->correction_release_at->isPast(),
            TdSet::CORRECTION_PREMIUM_ONLY => $hasPremium,
            default => false,
        };
    }

    protected function storeAttachment(Request $request): array
    {
        if (!$request->hasFile('attachment')) {
            return [null, null, null];
        }

        $file = $request->file('attachment');
        $original = $file->getClientOriginalName();
        $storedName = now()->format('YmdHis') . '_' . Str::slug(pathinfo($original, PATHINFO_FILENAME)) . '.' . $file->getClientOriginalExtension();
        $path = $file->storeAs('td-questions/attachments', $storedName);

        return [$path, $original, $file->getMimeType()];
    }
}
