@extends('layouts.admin')

@section('title', $tdSet->title)
@section('page_title', 'Détail du TD')
@section('page_subtitle', 'Lecture, validation et contrôle qualité du TD et de son corrigé.')

@section('content')
<section class="admin-panel">
    <div class="admin-panel__head admin-head-split">
        <div>
            <h2>{{ $tdSet->title }}</h2>
            <p>{{ $tdSet->schoolClass->name ?? '-' }} • {{ $tdSet->subject->name ?? '-' }} • {{ $tdSet->chapter_label ?: 'Sans chapitre' }}</p>
        </div>
        <div class="admin-table-actions">
            @if($tdSet->status !== 'published')
                <form method="POST" action="{{ route('admin.td.sets.publish', $tdSet) }}">@csrf<button class="btn btn--primary" type="submit">Publier</button></form>
            @endif
            @if($tdSet->status !== 'draft')
                <form method="POST" action="{{ route('admin.td.sets.draft', $tdSet) }}">@csrf<button class="btn btn--ghost" type="submit">Remettre en brouillon</button></form>
            @endif
            @if($tdSet->status !== 'archived')
                <form method="POST" action="{{ route('admin.td.sets.archive', $tdSet) }}">@csrf<button class="btn btn--ghost" type="submit">Archiver</button></form>
            @endif
        </div>
    </div>
    <div class="admin-panel__body">
        <div class="admin-detail-grid">
            <div><strong>Auteur</strong><span>{{ $tdSet->author->full_name ?? $tdSet->author->name ?? '-' }}</span></div>
            <div><strong>Statut</strong><span class="admin-badge admin-badge--{{ $tdSet->status }}">{{ $tdSet->status }}</span></div>
            <div><strong>Accès</strong><span>{{ $tdSet->access_level === 'premium' ? 'Premium' : 'Gratuit' }}</span></div>
            <div><strong>Mode corrigé</strong><span>{{ $tdSet->correction_mode }}</span></div>
            <div><strong>Type</strong><span>{{ $tdSet->td_type }}</span></div>
            <div><strong>Difficulté</strong><span>{{ $tdSet->difficulty }}</span></div>
        </div>
        @if($tdSet->summary)
            <div class="admin-rich-block"><h3>Résumé</h3><p>{{ $tdSet->summary }}</p></div>
        @endif
        <div class="admin-rich-block">
            <h3>Énoncé du TD</h3>
            <div class="td-rich-content ql-snow"><div class="ql-editor">{!! $tdSet->instructions_html !!}</div></div>
        </div>
        @if($tdSet->document_path)
            <div class="admin-doc-card"><strong>Document TD joint :</strong> {{ $tdSet->document_name }}</div>
        @endif
        <div class="admin-rich-block">
            <h3>Corrigé</h3>
            @if($tdSet->correction_html)
                <div class="td-rich-content ql-snow"><div class="ql-editor">{!! $tdSet->correction_html !!}</div></div>
            @else
                <p class="teacher-muted">Aucun corrigé rédigé pour le moment.</p>
            @endif
        </div>
        @if($tdSet->correction_document_path)
            <div class="admin-doc-card"><strong>Document corrigé joint :</strong> {{ $tdSet->correction_document_name }}</div>
        @endif
    </div>
</section>
@endsection
