@extends('layouts.admin')

@section('title', 'TD & corrigés')
@section('page_title', 'TD & corrigés')
@section('page_subtitle', 'Supervision complète des TD créés par les enseignants, avec filtres, validation et publication.')

@section('content')
<section class="admin-panel">
    <div class="admin-panel__head"><h2>Filtres</h2></div>
    <div class="admin-panel__body">
        <form method="GET" class="admin-filters-grid">
            <input type="text" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Rechercher un TD...">
            <select name="status">
                <option value="">Tous les statuts</option>
                @foreach(['draft' => 'Brouillon', 'submitted' => 'Soumis', 'published' => 'Publié', 'archived' => 'Archivé'] as $value => $label)
                    <option value="{{ $value }}" @selected(($filters['status'] ?? '') === $value)>{{ $label }}</option>
                @endforeach
            </select>
            <select name="access_level">
                <option value="">Tous les accès</option>
                <option value="free" @selected(($filters['access_level'] ?? '') === 'free')>Gratuit</option>
                <option value="premium" @selected(($filters['access_level'] ?? '') === 'premium')>Premium</option>
            </select>
            <select name="school_class_id">
                <option value="">Toutes les classes</option>
                @foreach($classes as $class)
                    <option value="{{ $class->id }}" @selected((string)($filters['school_class_id'] ?? '') === (string)$class->id)>{{ $class->name }}</option>
                @endforeach
            </select>
            <select name="subject_id">
                <option value="">Toutes les matières</option>
                @foreach($subjects as $subject)
                    <option value="{{ $subject->id }}" @selected((string)($filters['subject_id'] ?? '') === (string)$subject->id)>{{ $subject->name }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn btn--primary">Filtrer</button>
        </form>
    </div>
</section>

<section class="admin-panel">
    <div class="admin-panel__head"><h2>Bibliothèque des TD</h2></div>
    <div class="admin-panel__body admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Classe</th>
                    <th>Matière</th>
                    <th>Auteur</th>
                    <th>Statut</th>
                    <th>Accès</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($tdSets as $td)
                    <tr>
                        <td>
                            <strong>{{ $td->title }}</strong>
                            <div class="teacher-muted">{{ $td->chapter_label ?: 'Sans chapitre' }}</div>
                        </td>
                        <td>{{ $td->schoolClass->name ?? '-' }}</td>
                        <td>{{ $td->subject->name ?? '-' }}</td>
                        <td>{{ $td->author->full_name ?? $td->author->name ?? '-' }}</td>
                        <td><span class="admin-badge admin-badge--{{ $td->status }}">{{ $td->status }}</span></td>
                        <td>{{ $td->access_level === 'premium' ? 'Premium' : 'Gratuit' }}</td>
                        <td>
                            <div class="admin-table-actions">
                                <a href="{{ route('admin.td.sets.show', $td) }}" class="btn btn--ghost">Ouvrir</a>
                                @if($td->status !== 'published')
                                    <form method="POST" action="{{ route('admin.td.sets.publish', $td) }}">@csrf<button class="btn btn--primary" type="submit">Publier</button></form>
                                @endif
                                @if($td->status !== 'archived')
                                    <form method="POST" action="{{ route('admin.td.sets.archive', $td) }}">@csrf<button class="btn btn--ghost" type="submit">Archiver</button></form>
                                @endif
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="7">Aucun TD enregistré.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="admin-panel__body">{{ $tdSets->links() }}</div>
</section>
@endsection
