@extends('layouts.admin')

@section('title', 'Tableau de bord admin')
@section('page_title', 'Cockpit admin - Révision TD')
@section('page_subtitle', 'Vue d’ensemble des enseignants, affectations, TD publiés, questions en attente et activité de révision.')

@section('content')
<div class="admin-grid admin-grid--stats admin-grid--stats-six">
    <div class="admin-stat-card"><span class="admin-stat-card__label">Élèves</span><strong>{{ $stats['students'] }}</strong></div>
    <div class="admin-stat-card"><span class="admin-stat-card__label">Enseignants TD</span><strong>{{ $stats['teachers'] }}</strong></div>
    <div class="admin-stat-card"><span class="admin-stat-card__label">Affectations actives</span><strong>{{ $stats['assignments'] }}</strong></div>
    <div class="admin-stat-card"><span class="admin-stat-card__label">TD publiés</span><strong>{{ $stats['td_published'] }}</strong></div>
    <div class="admin-stat-card"><span class="admin-stat-card__label">TD à valider</span><strong>{{ $stats['td_submitted'] }}</strong></div>
    <div class="admin-stat-card"><span class="admin-stat-card__label">Questions ouvertes</span><strong>{{ $stats['td_questions_open'] }}</strong></div>
</div>

<div class="admin-grid admin-grid--two">
    <section class="admin-panel">
        <div class="admin-panel__head"><h2>Pilotage rapide</h2></div>
        <div class="admin-panel__body">
            <div class="admin-checklist">
                <div><strong>Classes</strong><span>{{ $stats['classes'] }}</span></div>
                <div><strong>TD au total</strong><span>{{ $stats['td_total'] }}</span></div>
                <div><strong>TD gratuits</strong><span>{{ $stats['td_free'] }}</span></div>
                <div><strong>TD premium</strong><span>{{ $stats['td_premium'] }}</span></div>
                <div><strong>Abonnements actifs</strong><span>{{ $stats['active_subscriptions'] }}</span></div>
                <div><strong>Paiements validés</strong><span>{{ $stats['completed_payments'] }}</span></div>
            </div>
        </div>
    </section>

    <section class="admin-panel">
        <div class="admin-panel__head"><h2>Actions immédiates</h2></div>
        <div class="admin-panel__body">
            <div class="admin-quick-actions">
                <a href="{{ route('admin.teachers.index') }}" class="admin-quick-card"><strong>Créer / gérer les enseignants</strong><span>Comptes, statut, activation</span></a>
                <a href="{{ route('admin.assignments.index') }}" class="admin-quick-card"><strong>Affecter les enseignants</strong><span>Classe + matière + enseignant</span></a>
                <a href="{{ route('admin.td.sets.index', ['status' => 'submitted']) }}" class="admin-quick-card"><strong>Valider les TD soumis</strong><span>Relire puis publier</span></a>
                <a href="{{ route('admin.td.questions.index', ['status' => 'open']) }}" class="admin-quick-card"><strong>Suivre les questions</strong><span>Conversations à surveiller</span></a>
            </div>
        </div>
    </section>
</div>

<div class="admin-grid admin-grid--two">
    <section class="admin-panel">
        <div class="admin-panel__head"><h2>TD récents</h2></div>
        <div class="admin-panel__body admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Titre</th>
                        <th>Classe</th>
                        <th>Matière</th>
                        <th>Statut</th>
                        <th>Accès</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($recentTds as $td)
                        <tr>
                            <td><a href="{{ route('admin.td.sets.show', $td) }}">{{ $td->title }}</a></td>
                            <td>{{ $td->schoolClass->name ?? '-' }}</td>
                            <td>{{ $td->subject->name ?? '-' }}</td>
                            <td><span class="admin-badge admin-badge--{{ $td->status }}">{{ $td->status }}</span></td>
                            <td>{{ $td->access_level === 'premium' ? 'Premium' : 'Gratuit' }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="5">Aucun TD pour le moment.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </section>

    <section class="admin-panel">
        <div class="admin-panel__head"><h2>Questions à suivre</h2></div>
        <div class="admin-panel__body admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>TD</th>
                        <th>Élève</th>
                        <th>Matière</th>
                        <th>Statut</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($openThreads as $thread)
                        <tr>
                            <td><a href="{{ route('admin.td.questions.show', $thread) }}">{{ $thread->tdSet->title ?? '-' }}</a></td>
                            <td>{{ $thread->student->full_name ?? $thread->student->name ?? '-' }}</td>
                            <td>{{ $thread->subject->name ?? '-' }}</td>
                            <td><span class="admin-badge admin-badge--{{ $thread->status }}">{{ $thread->status }}</span></td>
                        </tr>
                    @empty
                        <tr><td colspan="4">Aucune conversation TD récente.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </section>
</div>
@endsection
