<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Backoffice administrateur TIMAH SCHOOL">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Administration') - TIMAH SCHOOL</title>
    <style>{!! file_get_contents(public_path('assets/css/admin.css')) !!}</style>
</head>
<body>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <div class="admin-sidebar__top">
            <a href="{{ route('admin.dashboard') }}" class="admin-brand">
                <span class="admin-brand__mark">T</span>
                <span>
                    <strong>TIMAH SCHOOL</strong>
                    <small>Administration centrale</small>
                </span>
            </a>
        </div>

        <nav class="admin-nav">
            <div class="admin-nav__group-label">Pilotage</div>
            <a href="{{ route('admin.dashboard') }}" class="admin-link {{ request()->routeIs('admin.dashboard') ? 'is-active' : '' }}">📊 Tableau de bord</a>

            <div class="admin-nav__group-label">Encadrement</div>
            <a href="{{ route('admin.teachers.index') }}" class="admin-link {{ request()->routeIs('admin.teachers.*') ? 'is-active' : '' }}">👨‍🏫 Enseignants</a>
            <a href="{{ route('admin.assignments.index') }}" class="admin-link {{ request()->routeIs('admin.assignments.*') ? 'is-active' : '' }}">🧩 Affectations</a>

            <div class="admin-nav__group-label">Révision TD</div>
            <a href="{{ route('admin.td.sets.index') }}" class="admin-link {{ request()->routeIs('admin.td.sets.*') ? 'is-active' : '' }}">📝 TD & corrigés</a>
            <a href="{{ route('admin.td.questions.index') }}" class="admin-link {{ request()->routeIs('admin.td.questions.*') ? 'is-active' : '' }}">💬 Questions TD</a>
        </nav>

        <div class="admin-sidebar__bottom">
            <form method="POST" action="{{ route('admin.logout') }}">
                @csrf
                <button type="submit" class="admin-logout">Déconnexion admin</button>
            </form>
        </div>
    </aside>

    <div class="admin-main">
        <header class="admin-topbar">
            <div>
                <h1>@yield('page_title', 'Administration')</h1>
                <p>@yield('page_subtitle', 'Supervision complète des enseignants TD, des contenus de révision et des interactions élèves.') </p>
            </div>
            <div class="admin-topbar__actions">
                <a href="{{ route('admin.teachers.index') }}" class="btn btn--ghost">+ Enseignant</a>
                <a href="{{ route('admin.assignments.index') }}" class="btn btn--ghost">+ Affectation</a>
                <a href="{{ route('admin.td.sets.index') }}" class="btn btn--primary">Gérer les TD</a>
                <div class="admin-userbox">
                    <strong>{{ auth()->user()->full_name ?? auth()->user()->name ?? auth()->user()->username }}</strong>
                    <small>Compte administrateur</small>
                </div>
            </div>
        </header>

        <main class="admin-content">
            @if ($errors->any())
                <div class="admin-alert admin-alert--error">{{ $errors->first() }}</div>
            @endif
            @if(session('success'))
                <div class="admin-alert admin-alert--success">{{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="admin-alert admin-alert--error">{{ session('error') }}</div>
            @endif

            @yield('content')
        </main>
    </div>
</div>
</body>
</html>
