@extends('layouts.teacher')

@section('title', 'Tableau de bord enseignant')
@section('page_title', 'Tableau de bord enseignant TD')
@section('page_subtitle', 'Suivez vos classes affectées, vos TD, vos corrigés et les questions des élèves.')

@section('content')
<div class="teacher-grid teacher-grid--stats">
    <div class="teacher-stat-card"><span>Classes affectées</span><strong>{{ $stats['classes'] }}</strong></div>
    <div class="teacher-stat-card"><span>Matières affectées</span><strong>{{ $stats['subjects'] }}</strong></div>
    <div class="teacher-stat-card"><span>TD publiés</span><strong>{{ $stats['td_published'] }}</strong></div>
    <div class="teacher-stat-card"><span>Questions ouvertes</span><strong>{{ $stats['td_questions_open'] }}</strong></div>
</div>

<div class="teacher-grid teacher-grid--two">
    <section class="teacher-section">
        <div class="teacher-section__head"><h2>Production TD</h2></div>
        <div class="teacher-cards">
            <article class="teacher-card"><strong>Total TD</strong><p>{{ $stats['td_total'] }} TD créés sur vos affectations.</p></article>
            <article class="teacher-card"><strong>Brouillons</strong><p>{{ $stats['td_draft'] }} TD encore en préparation.</p></article>
            <article class="teacher-card"><strong>Soumis</strong><p>{{ $stats['td_submitted'] }} TD en attente de supervision.</p></article>
        </div>
    </section>
    <section class="teacher-section">
        <div class="teacher-section__head"><h2>Actions rapides</h2></div>
        <div class="teacher-cards teacher-cards--two">
            <a href="{{ route('teacher.td.sets.create') }}" class="teacher-card teacher-card--action"><strong>Nouveau TD</strong><p>Créer un TD et son corrigé.</p></a>
            <a href="{{ route('teacher.td.questions.index') }}" class="teacher-card teacher-card--action"><strong>Questions TD</strong><p>Répondre aux élèves.</p></a>
        </div>
    </section>
</div>

<div class="teacher-grid teacher-grid--two">
    <section class="teacher-panel">
        <div class="teacher-panel__head"><h2>Mes TD récents</h2></div>
        <div class="teacher-table-wrap">
            <table class="teacher-table">
                <thead><tr><th>Titre</th><th>Matière</th><th>Statut</th><th>Accès</th></tr></thead>
                <tbody>
                @forelse($recentTdSets as $td)
                    <tr>
                        <td>{{ $td->title }}</td>
                        <td>{{ $td->subject->name ?? '-' }}</td>
                        <td><span class="teacher-badge teacher-badge--{{ $td->status }}">{{ $td->status }}</span></td>
                        <td>{{ $td->access_level === 'premium' ? 'Premium' : 'Gratuit' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4">Aucun TD récent.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </section>

    <section class="teacher-panel">
        <div class="teacher-panel__head"><h2>Questions TD récentes</h2></div>
        <div class="teacher-table-wrap">
            <table class="teacher-table">
                <thead><tr><th>TD</th><th>Élève</th><th>Statut</th><th>Action</th></tr></thead>
                <tbody>
                @forelse($recentTdThreads as $thread)
                    <tr>
                        <td>{{ $thread->tdSet->title ?? '-' }}</td>
                        <td>{{ $thread->student->full_name ?? $thread->student->name ?? '-' }}</td>
                        <td><span class="teacher-badge teacher-badge--{{ $thread->status }}">{{ $thread->status }}</span></td>
                        <td><a href="{{ route('teacher.td.questions.show', $thread) }}">Ouvrir</a></td>
                    </tr>
                @empty
                    <tr><td colspan="4">Aucune question récente.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </section>
</div>
@endsection
