@extends('layouts.teacher')

@section('title', 'Mes TD')
@section('page_title', 'Mes TD')
@section('page_subtitle', 'Créez, relisez, soumettez et suivez vos TD par classe et par matière.')

@section('content')
<section class="teacher-section">
    <div class="teacher-section__head"><h2>Filtres</h2></div>
    <form method="GET" class="teacher-filter-grid">
        <input type="text" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Rechercher un TD...">
        <select name="status">
            <option value="">Tous les statuts</option>
            @foreach(['draft' => 'Brouillon', 'submitted' => 'Soumis', 'published' => 'Publié', 'archived' => 'Archivé'] as $value => $label)
                <option value="{{ $value }}" @selected(($filters['status'] ?? '') === $value)>{{ $label }}</option>
            @endforeach
        </select>
        <select name="subject_id">
            <option value="">Toutes les matières</option>
            @foreach($assignments as $assignment)
                <option value="{{ $assignment->subject_id }}" @selected((string)($filters['subject_id'] ?? '') === (string)$assignment->subject_id)>{{ $assignment->subject->name ?? '-' }}</option>
            @endforeach
        </select>
        <button type="submit" class="teacher-btn teacher-btn--ghost">Filtrer</button>
        <a href="{{ route('teacher.td.sets.create') }}" class="teacher-btn teacher-btn--primary">+ Nouveau TD</a>
    </form>
</section>

<section class="teacher-panel">
    <div class="teacher-panel__head"><h2>Bibliothèque de mes TD</h2></div>
    <div class="teacher-table-wrap">
        <table class="teacher-table">
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Classe</th>
                    <th>Matière</th>
                    <th>Statut</th>
                    <th>Accès</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            @forelse($tdSets as $td)
                <tr>
                    <td>
                        <strong>{{ $td->title }}</strong>
                        <div class="teacher-muted">{{ $td->chapter_label ?: 'Sans chapitre' }}</div>
                    </td>
                    <td>{{ $td->schoolClass->name ?? '-' }}</td>
                    <td>{{ $td->subject->name ?? '-' }}</td>
                    <td><span class="teacher-badge teacher-badge--{{ $td->status }}">{{ $td->status }}</span></td>
                    <td>{{ $td->access_level === 'premium' ? 'Premium' : 'Gratuit' }}</td>
                    <td>
                        <div class="teacher-table-actions">
                            <a href="{{ route('teacher.td.sets.edit', $td) }}" class="teacher-btn teacher-btn--ghost">Modifier</a>
                            @if($td->document_path)
                                <a href="{{ route('teacher.td.sets.document', $td) }}" class="teacher-btn teacher-btn--ghost">Énoncé</a>
                            @endif
                            @if($td->correction_document_path)
                                <a href="{{ route('teacher.td.sets.correction_document', $td) }}" class="teacher-btn teacher-btn--ghost">Corrigé doc</a>
                            @endif
                            <form method="POST" action="{{ route('teacher.td.sets.delete', $td) }}" onsubmit="return confirm('Supprimer ce TD ?');">
                                @csrf
                                <button type="submit" class="teacher-btn teacher-btn--danger">Supprimer</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6">Aucun TD enregistré.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    <div class="teacher-panel__pagination">{{ $tdSets->links() }}</div>
</section>
@endsection
