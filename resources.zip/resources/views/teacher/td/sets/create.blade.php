@extends('layouts.teacher')

@section('title', 'Nouveau TD')
@section('page_title', 'Créer un TD')
@section('page_subtitle', 'Rédigez l’énoncé, le corrigé, joignez les documents utiles et définissez l’accès gratuit ou premium.')

@push('head')
<link rel="stylesheet" href="https://cdn.quilljs.com/1.3.7/quill.snow.css">
@endpush

@section('content')
<form method="POST" action="{{ route('teacher.td.sets.store') }}" enctype="multipart/form-data" class="teacher-section">
    @csrf
    @include('teacher.td.sets._form')
    <div class="teacher-form-actions">
        <button type="submit" class="teacher-btn teacher-btn--primary">Enregistrer le TD</button>
        <a href="{{ route('teacher.td.sets.index') }}" class="teacher-btn teacher-btn--ghost">Retour</a>
    </div>
</form>
@endsection

@push('scripts')
<script src="https://cdn.quilljs.com/1.3.7/quill.min.js"></script>
<script>
    document.querySelectorAll('.js-td-editor').forEach(function (textarea) {
        var wrapper = document.createElement('div');
        wrapper.className = 'teacher-editor';
        var editor = document.createElement('div');
        editor.innerHTML = textarea.value || '';
        textarea.style.display = 'none';
        textarea.parentNode.insertBefore(wrapper, textarea);
        wrapper.appendChild(editor);

        var quill = new Quill(editor, {
            theme: 'snow',
            modules: {
                toolbar: [
                    [{ header: [1, 2, 3, false] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{ color: [] }, { background: [] }],
                    [{ list: 'ordered' }, { list: 'bullet' }],
                    [{ align: [] }],
                    ['blockquote', 'code-block', 'link', 'image'],
                    ['clean']
                ]
            }
        });

        textarea.form.addEventListener('submit', function () {
            textarea.value = quill.root.innerHTML;
        });
    });
</script>
@endpush
