@extends('layouts.teacher')

@section('title', 'Questions TD')
@section('page_title', 'Questions TD')
@section('page_subtitle', 'Répondez aux questions des élèves liées aux TD de vos matières affectées.')

@section('content')
<section class="teacher-section">
    <div class="teacher-section__head"><h2>Questions reçues</h2></div>
    <form method="GET" class="teacher-filter-grid">
        <select name="status">
            <option value="">Tous les statuts</option>
            @foreach(['open' => 'Ouvert', 'answered' => 'Répondu', 'closed' => 'Clos'] as $value => $label)
                <option value="{{ $value }}" @selected(($filters['status'] ?? '') === $value)>{{ $label }}</option>
            @endforeach
        </select>
        <button type="submit" class="teacher-btn teacher-btn--ghost">Filtrer</button>
    </form>
</section>

<section class="teacher-panel">
    <div class="teacher-panel__head"><h2>Conversations TD</h2></div>
    <div class="teacher-table-wrap">
        <table class="teacher-table">
            <thead><tr><th>TD</th><th>Élève</th><th>Matière</th><th>Statut</th><th>Dernier message</th><th>Action</th></tr></thead>
            <tbody>
                @forelse($threads as $thread)
                    <tr>
                        <td>{{ $thread->tdSet->title ?? '-' }}</td>
                        <td>{{ $thread->student->full_name ?? $thread->student->name ?? '-' }}</td>
                        <td>{{ $thread->subject->name ?? '-' }}</td>
                        <td><span class="teacher-badge teacher-badge--{{ $thread->status }}">{{ $thread->status }}</span></td>
                        <td>{{ optional($thread->last_message_at)->format('d/m/Y H:i') }}</td>
                        <td><a href="{{ route('teacher.td.questions.show', $thread) }}">Ouvrir</a></td>
                    </tr>
                @empty
                    <tr><td colspan="6">Aucune question TD pour le moment.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="teacher-panel__pagination">{{ $threads->links() }}</div>
</section>
@endsection
