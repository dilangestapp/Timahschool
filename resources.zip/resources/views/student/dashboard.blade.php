@extends('layouts.student')

@section('title', 'Tableau de bord')

@section('content')
<section class="status-card">
    <div class="status-card__inner">
        <div class="status-card__head">
            <div>
                <h1>Bonjour, {{ auth()->user()->full_name ?? auth()->user()->name }} ! 👋</h1>
                <p>Vous êtes en <strong style="color:#fff;">{{ $studentProfile?->schoolClass?->name ?? 'Classe non définie' }}</strong></p>
            </div>
            <div class="status-chip">
                <strong>{{ $subscription && $subscription->isActive() ? '✓' : '!' }}</strong>
                <span>{{ $subscription && $subscription->isActive() ? 'Actif' : 'Inactif' }}</span>
            </div>
        </div>

        @if($subscription && $subscription->is_trial)
            <div class="status-banner status-banner--warning">
                <div>⏳</div>
                <div class="status-banner__body">
                    <strong>Essai gratuit en cours</strong>
                    <div>Expire dans {{ $subscription->ends_at->diffInHours(now()) }} heures.</div>
                </div>
                <a href="{{ route('student.subscription.index') }}" class="btn btn--light">S'abonner</a>
            </div>
        @elseif($subscription && $subscription->isActive())
            <div class="status-banner status-banner--success">
                <div>✅</div>
                <div class="status-banner__body">
                    <strong>Abonnement actif</strong>
                    <div>Valide jusqu'au {{ $subscription->ends_at->format('d/m/Y') }}.</div>
                </div>
            </div>
        @else
            <div class="status-banner status-banner--danger">
                <div>⚠️</div>
                <div class="status-banner__body">
                    <strong>Aucun abonnement actif</strong>
                    <div>Souscrivez pour accéder à tous les TD premium et leurs corrigés détaillés.</div>
                </div>
                <a href="{{ route('student.subscription.index') }}" class="btn btn--light">Voir les offres</a>
            </div>
        @endif
    </div>
</section>

<div class="card-grid">
    <article class="metric-card">
        <div class="metric-icon metric-icon--indigo">📝</div>
        <div><div class="metric-label">TD publiés</div><div class="metric-value">{{ $tdProgress['published'] }}</div></div>
    </article>
    <article class="metric-card">
        <div class="metric-icon metric-icon--violet">⌛</div>
        <div><div class="metric-label">TD commencés</div><div class="metric-value">{{ $tdProgress['started'] }}</div></div>
    </article>
    <article class="metric-card">
        <div class="metric-icon metric-icon--green">✅</div>
        <div><div class="metric-label">TD terminés</div><div class="metric-value">{{ $tdProgress['submitted'] }}</div></div>
    </article>
</div>

<section class="panel">
    <div class="panel__head">
        <h2>TD récents</h2>
        <a href="{{ route('student.td.index') }}" class="muted">Voir tous les TD</a>
    </div>
    <div class="panel__body">
        @forelse($recentTdSets as $td)
            <div class="list-item">
                <div style="display:flex; align-items:center; gap:14px;">
                    <div class="subject-mark" style="background-color: {{ $td->subject->color ?? '#4F46E5' }};">{{ $td->subject->initials ?? 'TD' }}</div>
                    <div>
                        <strong><a href="{{ route('student.td.show', $td) }}">{{ $td->title }}</a></strong>
                        <div class="muted">{{ $td->subject->name ?? '-' }} • {{ $td->chapter_label ?: 'Sans chapitre' }}</div>
                    </div>
                </div>
                <div class="muted">{{ $td->access_level === 'premium' ? 'Premium' : 'Gratuit' }}</div>
            </div>
        @empty
            <div class="empty-state">Aucun TD disponible pour le moment.</div>
        @endforelse
    </div>
</section>

<div class="shortcut-grid">
    <a href="{{ route('student.td.index') }}" class="shortcut-card shortcut-card--primary">
        <div class="shortcut-card__head"><div><h3>Révision par TD</h3><p>Entraînez-vous matière par matière avec corrigés et questions.</p></div><div class="shortcut-icon">📝</div></div>
    </a>
    <a href="{{ route('student.messages.index') }}" class="shortcut-card">
        <div class="shortcut-card__head"><div><h3>Mes échanges</h3><p>Retrouvez vos discussions avec les enseignants et vos questions.</p></div><div class="shortcut-icon">💬</div></div>
    </a>
</div>
@endsection
