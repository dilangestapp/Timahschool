@extends('layouts.student')

@section('title', $tdSet->title)

@push('head')
<link rel="stylesheet" href="https://cdn.quilljs.com/1.3.7/quill.snow.css">
@endpush

@section('content')
<section class="panel td-show-panel">
    <div class="panel__head td-show-head">
        <div>
            <h2>{{ $tdSet->title }}</h2>
            <div class="muted">{{ $tdSet->schoolClass->name ?? '-' }} • {{ $tdSet->subject->name ?? '-' }} • {{ $tdSet->chapter_label ?: 'Sans chapitre' }}</div>
        </div>
        <div class="td-chip-row">
            <span class="td-chip td-chip--{{ $tdSet->difficulty }}">{{ $tdSet->difficulty === 'exam' ? 'Examen' : ucfirst($tdSet->difficulty) }}</span>
            <span class="td-chip td-chip--{{ $tdSet->access_level }}">{{ $tdSet->access_level === 'premium' ? 'Premium' : 'Gratuit' }}</span>
        </div>
    </div>
    <div class="panel__body td-show-body">
        @if($tdSet->summary)
            <div class="td-note-box">{{ $tdSet->summary }}</div>
        @endif
        <div class="td-meta-grid">
            <div><strong>Durée estimée</strong><span>{{ $tdSet->estimated_minutes ?: '-' }} min</span></div>
            <div><strong>Type</strong><span>{{ ucfirst(str_replace('_', ' ', $tdSet->td_type)) }}</span></div>
            <div><strong>Règle corrigé</strong><span>{{ str_replace('_', ' ', $tdSet->correction_mode) }}</span></div>
            <div><strong>Auteur</strong><span>{{ $tdSet->author->full_name ?? $tdSet->author->name ?? '-' }}</span></div>
        </div>

        <div class="td-rich-content ql-snow"><div class="ql-editor">{!! $tdSet->instructions_html !!}</div></div>

        @if($tdSet->document_path)
            <div class="td-doc-card">
                <div>
                    <strong>Document du TD</strong>
                    <div class="muted">{{ $tdSet->document_name }}</div>
                </div>
                <a href="{{ route('student.td.document', $tdSet) }}" class="btn btn--ghost">Ouvrir / télécharger</a>
            </div>
        @endif

        @if($tdSet->correction_mode === 'after_submit' && !$attempt->correction_unlocked_at)
            <form method="POST" action="{{ route('student.td.submit', $tdSet) }}" class="td-inline-form">
                @csrf
                <button type="submit" class="btn btn--primary">J’ai terminé ce TD, débloquer le corrigé</button>
            </form>
        @endif

        <div class="td-correction-block">
            <div class="td-correction-block__head">
                <h3>Corrigé du TD</h3>
                @if(!$canViewCorrection)
                    <span class="td-lock-note">Corrigé verrouillé selon la règle définie par l’enseignant.</span>
                @endif
            </div>
            @if($canViewCorrection)
                @if($tdSet->correction_html)
                    <div class="td-rich-content ql-snow"><div class="ql-editor">{!! $tdSet->correction_html !!}</div></div>
                @else
                    <div class="empty-state">Le corrigé n’a pas encore été rédigé.</div>
                @endif
                @if($tdSet->correction_document_path)
                    <div class="td-doc-card">
                        <div>
                            <strong>Document corrigé</strong>
                            <div class="muted">{{ $tdSet->correction_document_name }}</div>
                        </div>
                        <a href="{{ route('student.td.correction_document', $tdSet) }}" class="btn btn--ghost">Ouvrir / télécharger</a>
                    </div>
                @endif
            @endif
        </div>
    </div>
</section>

<section class="panel td-show-panel">
    <div class="panel__head"><h2>Poser une question sur ce TD</h2></div>
    <div class="panel__body">
        <form method="POST" action="{{ route('student.td.ask', $tdSet) }}" enctype="multipart/form-data" class="td-question-form">
            @csrf
            <textarea name="message_html" rows="4" placeholder="Expliquez précisément votre difficulté ou la partie que vous n’avez pas comprise."></textarea>
            <div class="td-question-form__row">
                <input type="file" name="attachment">
                <button type="submit" class="btn btn--primary">Envoyer ma question</button>
            </div>
        </form>

        <div class="td-thread-list">
            @forelse(optional($thread)->messages ?? [] as $message)
                <article class="td-thread-bubble {{ $message->sender_role === 'student' ? 'td-thread-bubble--out' : 'td-thread-bubble--in' }}">
                    <div class="td-thread-bubble__meta">{{ $message->sender->full_name ?? $message->sender->name ?? '-' }} • {{ $message->created_at->format('d/m/Y H:i') }}</div>
                    @if($message->message_html)
                        <div class="td-thread-bubble__body">{!! $message->message_html !!}</div>
                    @endif
                    @if($message->attachment_path)
                        <div class="td-doc-card td-doc-card--mini"><a href="{{ route('student.td.messages.attachment', $message) }}">{{ $message->attachment_name }}</a></div>
                    @endif
                </article>
            @empty
                <div class="empty-state">Aucune question envoyée pour ce TD.</div>
            @endforelse
        </div>
    </div>
</section>
@endsection
