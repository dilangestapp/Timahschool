@extends('layouts.student')

@section('title', 'Révision TD')

@section('content')
<section class="panel td-student-panel">
    <div class="panel__head">
        <h2>Révision par TD</h2>
        <span class="muted">{{ $studentProfile->schoolClass->name ?? '-' }}</span>
    </div>
    <div class="panel__body td-student-panel__body">
        <form method="GET" class="td-filter-grid">
            <input type="text" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Rechercher un TD...">
            <select name="subject_id">
                <option value="">Toutes les matières</option>
                @foreach($tdSets->getCollection()->pluck('subject')->filter()->unique('id') as $subject)
                    <option value="{{ $subject->id }}" @selected((string)($filters['subject_id'] ?? '') === (string)$subject->id)>{{ $subject->name }}</option>
                @endforeach
            </select>
            <select name="difficulty">
                <option value="">Tous les niveaux</option>
                <option value="easy" @selected(($filters['difficulty'] ?? '') === 'easy')>Facile</option>
                <option value="medium" @selected(($filters['difficulty'] ?? '') === 'medium')>Moyen</option>
                <option value="exam" @selected(($filters['difficulty'] ?? '') === 'exam')>Niveau examen</option>
            </select>
            <select name="access_level">
                <option value="">Tous les accès</option>
                <option value="free" @selected(($filters['access_level'] ?? '') === 'free')>Gratuit</option>
                <option value="premium" @selected(($filters['access_level'] ?? '') === 'premium')>Premium</option>
            </select>
            <button type="submit" class="btn btn--primary">Filtrer</button>
        </form>

        <div class="td-card-grid">
            @forelse($tdSets as $td)
                <article class="td-card {{ $td->access_level === 'premium' ? 'td-card--premium' : '' }}">
                    <div class="td-card__head">
                        <span class="td-chip td-chip--{{ $td->difficulty }}">{{ $td->difficulty === 'exam' ? 'Examen' : ucfirst($td->difficulty) }}</span>
                        <span class="td-chip td-chip--{{ $td->access_level }}">{{ $td->access_level === 'premium' ? 'Premium' : 'Gratuit' }}</span>
                    </div>
                    <h3>{{ $td->title }}</h3>
                    <p class="muted">{{ $td->subject->name ?? '-' }} • {{ $td->chapter_label ?: 'Sans chapitre' }}</p>
                    <p>{{ $td->summary ?: 'TD de révision prêt à être travaillé.' }}</p>
                    <div class="td-card__meta">
                        <span>⏱ {{ $td->estimated_minutes ?: '-' }} min</span>
                        <span>🧾 {{ ucfirst(str_replace('_', ' ', $td->td_type)) }}</span>
                    </div>
                    @if($td->access_level === 'premium' && !$subscriptionActive)
                        <div class="td-lock-note">Réservé à l’abonnement premium.</div>
                    @endif
                    <a href="{{ route('student.td.show', $td) }}" class="btn btn--primary btn--full">Ouvrir le TD</a>
                </article>
            @empty
                <div class="empty-state">Aucun TD disponible pour le moment.</div>
            @endforelse
        </div>

        <div class="td-pagination">{{ $tdSets->links() }}</div>
    </div>
</section>
@endsection
